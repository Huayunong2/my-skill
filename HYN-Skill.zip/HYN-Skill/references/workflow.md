# HYN workflow modes

## Bootstrap a new project

1. Resolve the project root and inspect the existing tree.
2. Read applicable `AGENTS.md`, README files, and existing documentation indexes.
3. Inspect Git status without changing it.
4. Resolve profile and configuration.
5. Produce a preview of files to create and files to skip.
6. Apply only after explicit confirmation.
7. Reinspect, validate the generated structure, and report unresolved questions.

Use `project_foundation.py inspect` for discovery and `init` for the plan/apply lifecycle.

## Adopt an existing project

Do not rewrite existing documentation during the first pass. Report:

- the current project entry point;
- the current instruction and context files;
- duplicate or conflicting sources of truth;
- missing ownership, boundary, and verification information;
- the smallest safe set of missing files.

Only create missing files after the user confirms the preview. Existing files remain unchanged by the deterministic helper.

## Design a feature

Record the minimum useful decision context:

```text
intent → facts and constraints → owner and boundary → lifecycle → failure/side effects → verification → decision record
```

Use the project's existing architecture when it already owns the relevant invariant. Do not introduce a second state model merely because the new feature has a new UI or adapter.

## Change an existing project

Read project rules first. Keep the diff limited to the requested behavior and the direct documentation or verification changes required by that behavior. Do not create a new workflow file for a one-off note if an existing document already owns the topic.

## Harvest a lesson

Capture the lesson with:

- observation;
- affected project and conditions;
- benefit and cost;
- counterexample or limitation;
- proposed scope: project-local, profile-level, or HYN-global;
- promotion decision.

Never silently edit the personal Skill from a single project incident.

## Safe application contract

The helper defaults to preview mode. `--apply` may create missing files and parent directories, but it must not overwrite, delete, rename, or reformat existing project files. Invalid configuration must stop before any write.
