# HYN-Skill validation

Validation covers the Skill package and the generated project behavior.

## Package checks

- frontmatter has a valid lowercase technical name and non-empty description;
- UI metadata names `HYN-Skill` and points to a valid default prompt;
- every reference named by `SKILL.md` exists;
- templates and profile data exist;
- no initializer TODO placeholders remain;
- no machine-specific absolute path is required by the Skill;
- ZIP extraction has one complete Skill directory and no caches or temporary files.

## Script checks

- `inspect` is read-only;
- `init` without `--apply` is read-only;
- `--apply` creates only missing files;
- existing important files remain byte-for-byte unchanged;
- a second apply is idempotent;
- invalid configuration causes zero writes;
- output is available as text and JSON;
- profile detection reports evidence and ambiguity;
- generated templates have no unresolved tokens.

## Minimum scenarios

Test an empty project, Python project, CMake/C++ project, TypeScript/Web project, AI/Agent project, docs project, ambiguous project, existing-file project, invalid-config project, and repeated initialization.

Use temporary directories and the Python standard-library `unittest` runner. Do not use a live project as a fixture.
