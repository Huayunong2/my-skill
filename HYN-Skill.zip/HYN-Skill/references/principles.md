# HYN engineering principles

These are the portable parts of HYN's engineering style. They guide decisions; they are not a reason to impose a particular language, framework, or architecture.

## 1. Facts before implementation

Separate what the repository proves from what the user wants, what is inferred, and what is still a proposal. When a fact is uncertain, record the uncertainty and the next way to verify it.

## 2. One owner for each important fact

Every durable business fact, environment fact, resource reservation, and external side effect needs a clear owner. Do not add a second mutable state merely to make a page, adapter, or script easier to use.

## 3. Boundaries are first-class design objects

Identify where input enters, where output leaves, where asynchronous work starts and stops, where persistence commits, where external devices are touched, and where a public contract becomes stable.

## 4. Failure includes side effects

Do not reduce a failed operation to a boolean when it may have partially completed. Preserve useful evidence, distinguish cancellation from timeout, and make uncertain acceptance visible before deciding whether retry is safe.

## 5. Verification claims must match evidence

Label conclusions as appropriate: current-code fact, automated test, measurement, real-environment observation, inference, proposal, or pending verification. Host tests and simulated data do not prove real-device behavior.

## 6. Ceremony follows risk

Use the smallest workflow that protects the project. A small script may need only `README.md` and `CONTEXT.md`; hardware, long-lived, collaborative, or externally visible projects may need Agent rules, decision records, evidence records, and historical archives.

## 7. Documentation evolves with the system

Create a navigation point early. Update current documentation when current behavior changes. Record a decision when the reason matters. Archive only material historical states; do not turn every session into a diary.

## 8. Learnings need a promotion gate

A project lesson remains project-local until it has a clear applicability condition, a measurable benefit, and no known simpler alternative. Promote a lesson into HYN preferences only after it recurs across projects or HYN explicitly approves it.

## Deliberately non-universal rules

Hardware terms, HIL requirements, reducer/event architectures, specific error types, comment languages, date-based archive layouts, and personal vocabulary belong in a project profile or project rules file. They do not belong in the portable core unless a future cross-project review promotes them.
