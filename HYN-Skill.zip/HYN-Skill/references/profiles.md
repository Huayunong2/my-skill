# Project profiles

Profiles are lightweight adapters. They provide observable detection markers, documentation focus, suggested initialization level, and command-discovery hints. They do not prescribe frameworks or generate language scaffolding.

## Built-in profiles

- `generic`: fallback when evidence is weak or ambiguous.
- `python`: Python source and packaging markers.
- `cpp`: C/C++ build-system and source markers.
- `typescript-web`: Node, TypeScript, and web-tooling markers.
- `ai-agent`: multiple independent Agent, Skill, Prompt, Eval, or model-configuration markers.
- `docs`: documentation tooling or a repository dominated by Markdown and publication files.

## Detection rules

Detection is based on files and directories visible under the project root. Build output, dependency caches, VCS metadata, and common virtual environments are ignored.

Strong markers count more than generic source suffixes. AI/Agent detection requires multiple independent signals and must not trigger merely because a project has `AGENTS.md`.

When explicit configuration selects a profile, the helper still reports detection evidence but uses the explicit profile. When auto-detection produces a tie, use `generic` and report the candidates instead of guessing.

## Adding a profile

Add one table to `assets/profiles.toml` with:

- `strong_markers`;
- `markers`;
- `directories`;
- `source_suffixes`;
- `minimum_signals`;
- `suggested_level`;
- `focus`.

Add a detection fixture and update this reference. Keep profile data declarative; put a rule in `SKILL.md` only when it applies across project types.
