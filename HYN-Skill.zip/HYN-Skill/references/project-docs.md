# Project document layers

HYN-Skill creates a small, navigable document system. Each file has one responsibility.

| File or directory | Authority and purpose |
| --- | --- |
| `README.md` | Human-facing project purpose, quick start, and links. |
| `AGENTS.md` | Current project Agent behavior, commands, conventions, architecture constraints, and safety rules. |
| `CONTEXT.md` | Current facts, vocabulary, ownership, boundaries, open questions, and evidence limits. |
| `docs/README.md` | Formal documentation navigation. |
| `docs/decisions/` | Decisions whose rationale should remain discoverable. |
| `docs/verification/` | Tests, measurements, environment conditions, and what remains unverified. |
| `docs/glossary.md` | Terms that need stable shared meaning. |
| `docs/archive/` | Material historical states, not a chronological command log. |
| `learn/README.md` | Knowledge that is useful across tasks but is not the project's authoritative current fact. |
| `learn/map.md` | A deeper reading path for long-lived or complex projects. |

## AGENTS.md and HYN-Skill

HYN-Skill is the reusable personal workflow. It tells an agent how HYN initializes, inspects, documents, validates, and learns across projects.

`AGENTS.md` is the current project's shared contract. It must stand on its own and contain only facts and rules that apply to that project. It may point to `CONTEXT.md` and `docs/`, but it should not copy HYN's private preference file or the full Skill instructions.

## Initialization levels

| Level | Files |
| --- | --- |
| `lean` | `README.md`, `CONTEXT.md`, `docs/README.md` |
| `standard` | `lean` plus `AGENTS.md`, decision index, verification index, `learn/README.md` |
| `deep` | `standard` plus glossary, archive index, `learn/map.md` |

Templates should remain short and useful. A placeholder is acceptable only when it identifies a real fact the project owner still needs to provide.
