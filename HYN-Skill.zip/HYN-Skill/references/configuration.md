# HYN-Skill configuration

## Configuration files

Global preferences are optional:

```text
$XDG_CONFIG_HOME/hyn-skill/preferences.toml
```

When `XDG_CONFIG_HOME` is unset, use the platform home directory's `.config/hyn-skill/preferences.toml` path. Do not create it automatically.

Project overrides are optional and live at the project root:

```text
.hyn-skill.toml
```

Do not create an empty project configuration file. Generate the example only when the user asks for a project override.

## Supported schema

```toml
schema_version = 1
profile = "auto"
level = "standard"
language = "auto"
history = "material-change"
```

Allowed values:

- `profile`: `auto`, `generic`, `python`, `cpp`, `typescript-web`, `ai-agent`, `docs`;
- `level`: `lean`, `standard`, `deep`;
- `language`: `auto`, `zh-CN`, `en`;
- `history`: `none`, `material-change`, `dated`;
- `schema_version`: integer `1`.

Unknown keys are errors. This keeps a typo from silently changing the initialization result.

## Precedence

Merge in this exact order:

```text
built-in defaults
< selected profile defaults
< HYN global preferences
< project configuration
< explicit CLI or user overrides
```

The resolved profile is selected before profile defaults are applied. An explicit profile wins over auto-detection. A tie in auto-detection falls back to `generic` and reports the candidates.

## Parser compatibility

The helper tries `tomllib`, then `tomli`, then `toml`, so it can run on Python 3.10 and newer. If a configuration exists but no supported parser is available, fail with an actionable diagnostic. If no configuration exists, built-in defaults remain usable.

## Diagnostics

Every configuration error reports:

- source file;
- key path or line-level parser message when available;
- expected values;
- whether any project file was written.

Configuration is resolved before the write phase, so an invalid global or project file produces zero project mutations.
