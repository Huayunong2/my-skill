---
name: hyn-skill
description: Initialize or audit a project's engineering foundation with context, AGENTS.md rules, documentation, validation evidence, and configurable project conventions. Use for new project setup, existing-project onboarding, or deliberate documentation and workflow consolidation; do not invoke for ordinary coding changes unless the user asks for foundation work.
metadata:
  short-description: Personal project foundation and workflow initializer
---

# HYN-Skill

HYN-Skill is a personal project-foundation workflow. It establishes the smallest useful set of project context, agent rules, documentation indexes, decision records, and verification guidance without forcing every project to use the same architecture.

## Route the request

Choose one mode before reading detailed references:

- `bootstrap`: initialize a new or partially initialized project.
- `adopt`: inspect an existing project and report foundation gaps.
- `design`: record boundaries, ownership, lifecycle, failure semantics, and validation for a proposed feature.
- `change`: keep project context and evidence aligned while making a requested change.
- `harvest`: turn repeated, cross-project lessons into candidates for HYN preferences; never promote a one-off lesson automatically.

For ordinary implementation, debugging, or review work, use the more specific skill unless the user explicitly asks for HYN-Skill foundation work.

## Shared workflow

1. Locate the project root and read applicable `AGENTS.md`, `CONTEXT.md`, README files, and existing documentation indexes before proposing changes.
2. Inspect the current tree and Git status without modifying anything.
3. Load configuration in this order: built-in defaults, detected profile defaults, HYN global preferences, project `.hyn-skill.toml`, then explicit user or CLI overrides.
4. Read only the reference needed for the selected mode and profile:
   - [principles](references/principles.md) for portable HYN engineering principles.
   - [workflow](references/workflow.md) for mode-specific steps.
   - [configuration](references/configuration.md) for configuration and diagnostics.
   - [project docs](references/project-docs.md) for generated-document responsibilities.
   - [profiles](references/profiles.md) for project detection and profile behavior.
   - [validation](references/validation.md) for checks and acceptance criteria.
5. For `bootstrap` or `adopt`, run the deterministic script in preview mode first:

   ```bash
   python3 scripts/project_foundation.py inspect --project PATH
   python3 scripts/project_foundation.py init --project PATH
   ```

6. Show the resolved profile, effective configuration, files to create, files being skipped, warnings, and next actions. Apply only after explicit confirmation or an explicit `--apply` request:

   ```bash
   python3 scripts/project_foundation.py init --project PATH --apply
   ```

7. After applying, rerun inspection and the relevant validation checks. Report created files, preserved files, unresolved questions, and evidence limits.

## Non-negotiable boundaries

- Never overwrite, delete, rename, or reformat an existing important project file during initialization.
- Never create a second mutable source of truth merely to satisfy a template.
- Never turn an inference, FAKE run, or host-only test into a real-environment claim.
- Keep HYN personal preferences out of project `AGENTS.md` unless the project explicitly adopts them.
- Do not create history or learning files merely for ceremony; use the selected initialization level and project risk.
- Do not include machine-specific absolute paths in generated project documentation.

## Handoff

The project `AGENTS.md` owns current project-specific commands, conventions, architecture constraints, and safety rules. `CONTEXT.md` owns current facts and vocabulary. `docs/` owns stable decisions and verification records. `learn/` owns cross-project or not-yet-stable knowledge. HYN-Skill owns the reusable personal workflow that creates and maintains these layers.
