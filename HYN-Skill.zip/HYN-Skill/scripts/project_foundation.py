#!/usr/bin/env python3
"""Inspect and initialize a project's HYN engineering foundation.

The command is deliberately conservative: inspection and planning are read-only;
apply creates missing files only and never overwrites existing project files.
"""

from __future__ import annotations

import argparse
import datetime as _datetime
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable


SKILL_ROOT = Path(__file__).resolve().parents[1]
ASSET_ROOT = SKILL_ROOT / "assets"
TEMPLATE_ROOT = ASSET_ROOT / "templates"
DEFAULT_CONFIG_PATH = ASSET_ROOT / "defaults.toml"
PROFILE_CONFIG_PATH = ASSET_ROOT / "profiles.toml"
PROJECT_CONFIG_NAME = ".hyn-skill.toml"
GLOBAL_CONFIG_RELATIVE = Path("hyn-skill") / "preferences.toml"

PROFILE_NAMES = ("generic", "python", "cpp", "typescript-web", "ai-agent", "docs")
LEVELS = ("lean", "standard", "deep")
LANGUAGES = ("auto", "zh-CN", "en")
HISTORY_MODES = ("none", "material-change", "dated")
CONFIG_KEYS = {"schema_version", "profile", "level", "language", "history"}
IGNORED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "env",
    "node_modules",
    "build",
    "dist",
    "target",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".hyn-skill",
}
FOUNDATION_DOCUMENTS = {
    "README.md",
    "AGENTS.md",
    "CONTEXT.md",
    "docs/README.md",
    "docs/decisions/README.md",
    "docs/verification/README.md",
    "docs/glossary.md",
    "docs/archive/README.md",
    "learn/README.md",
    "learn/map.md",
}

DEFAULTS_FALLBACK = {
    "schema_version": 1,
    "profile": "auto",
    "level": "standard",
    "language": "auto",
    "history": "material-change",
}
PROFILES_FALLBACK = {
    "generic": {
        "label": "通用项目",
        "strong_markers": [],
        "markers": [],
        "directories": [],
        "source_suffixes": [],
        "minimum_signals": 0,
        "suggested_level": "standard",
        "focus": ["先明确项目目标、当前状态和事实拥有者"],
    }
}


class HynError(Exception):
    """A user-actionable validation or filesystem error."""


def _toml_module() -> tuple[Any, str]:
    """Return the first available TOML parser and its name."""

    try:
        import tomllib  # type: ignore[import-not-found]

        return tomllib, "tomllib"
    except ModuleNotFoundError:
        pass

    try:
        import tomli  # type: ignore[import-not-found]

        return tomli, "tomli"
    except ModuleNotFoundError:
        pass

    try:
        import toml  # type: ignore[import-not-found]

        return toml, "toml"
    except ModuleNotFoundError as exc:
        raise HynError(
            "TOML 配置文件存在，但当前 Python 没有 tomllib、tomli 或 toml。"
            "请使用 Python 3.11+，或安装 tomli/toml 后重试。"
        ) from exc


def _load_toml(path: Path) -> dict[str, Any]:
    module, module_name = _toml_module()
    try:
        if module_name in {"tomllib", "tomli"}:
            with path.open("rb") as stream:
                result = module.load(stream)
        else:
            result = module.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError) as exc:
        raise HynError(f"无法解析 TOML 文件 {path}: {exc}") from exc
    if not isinstance(result, dict):
        raise HynError(f"TOML 文件 {path} 的顶层必须是表。")
    return result


def _load_defaults() -> dict[str, Any]:
    try:
        return _load_toml(DEFAULT_CONFIG_PATH)
    except HynError as exc:
        if "没有 tomllib" in str(exc):
            return dict(DEFAULTS_FALLBACK)
        raise


def _load_profiles() -> dict[str, dict[str, Any]]:
    try:
        data = _load_toml(PROFILE_CONFIG_PATH)
    except HynError as exc:
        if "没有 tomllib" in str(exc):
            return dict(PROFILES_FALLBACK)
        raise
    profiles = data.get("profiles")
    if not isinstance(profiles, dict):
        raise HynError(f"Profile 文件 {PROFILE_CONFIG_PATH} 缺少 [profiles.*] 表。")
    normalized: dict[str, dict[str, Any]] = {}
    for name, value in profiles.items():
        if not isinstance(name, str) or not isinstance(value, dict):
            raise HynError(f"Profile 文件 {PROFILE_CONFIG_PATH} 包含无效的 profile 表。")
        normalized[name] = value
    return normalized


def _validate_config(data: dict[str, Any], source: Path) -> dict[str, Any]:
    unknown = sorted(set(data) - CONFIG_KEYS)
    if unknown:
        raise HynError(
            f"配置 {source} 包含未知键: {', '.join(unknown)}。"
            f"允许键为: {', '.join(sorted(CONFIG_KEYS))}。"
        )

    result = dict(data)
    version = result.get("schema_version", 1)
    if version != 1 or not isinstance(version, int) or isinstance(version, bool):
        raise HynError(f"配置 {source} 的 schema_version 必须是整数 1。")
    result["schema_version"] = 1

    for key, allowed in (
        ("profile", ("auto", *PROFILE_NAMES)),
        ("level", LEVELS),
        ("language", LANGUAGES),
        ("history", HISTORY_MODES),
    ):
        if key in result and result[key] not in allowed:
            choices = ", ".join(allowed)
            raise HynError(f"配置 {source} 的 {key}={result[key]!r} 无效，允许值为: {choices}。")
    return result


def _read_optional_config(path: Path) -> tuple[dict[str, Any], list[str]]:
    if not path.exists():
        return {}, []
    if not path.is_file():
        raise HynError(f"配置路径不是普通文件: {path}")
    return _validate_config(_load_toml(path), path), [str(path)]


def _global_config_path() -> Path:
    configured = os.environ.get("XDG_CONFIG_HOME")
    if configured:
        return Path(configured).expanduser() / GLOBAL_CONFIG_RELATIVE
    return Path.home() / ".config" / GLOBAL_CONFIG_RELATIVE


def _iter_files(root: Path) -> Iterable[Path]:
    for current, directories, filenames in os.walk(root, followlinks=False):
        directories[:] = sorted(name for name in directories if name not in IGNORED_DIRS)
        for filename in sorted(filenames):
            yield Path(current) / filename


def _relative(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def _existing_marker(root: Path, marker: str) -> bool:
    return (root / marker).exists()


def _score_profile(root: Path, profile: dict[str, Any], files: list[Path]) -> tuple[int, list[str]]:
    score = 0
    evidence: list[str] = []
    relative_files = {_relative(path, root) for path in files}
    file_names = {path.name for path in files}

    for marker in profile.get("strong_markers", []):
        if marker in relative_files or marker in file_names or _existing_marker(root, marker):
            score += 5
            evidence.append(f"strong marker: {marker}")
    for marker in profile.get("markers", []):
        # A directory listed in both markers and directories is one signal, not two.
        if marker in profile.get("directories", []) and (root / marker).is_dir():
            continue
        if marker in relative_files or marker in file_names or _existing_marker(root, marker):
            score += 2
            evidence.append(f"marker: {marker}")
    for directory in profile.get("directories", []):
        if (root / directory).is_dir():
            score += 2
            evidence.append(f"directory: {directory}/")

    suffixes = set(profile.get("source_suffixes", []))
    suffix_matches = sum(1 for path in files if path.suffix in suffixes)
    if suffix_matches and profile.get("label") != "文档型项目":
        score += min(3, suffix_matches)
        evidence.append(f"source suffixes: {suffix_matches} matching file(s)")

    if profile.get("label") == "文档型项目":
        project_documents = [
            path
            for path in files
            if path.suffix.lower() in {".md", ".mdx", ".rst"}
            and _relative(path, root) not in FOUNDATION_DOCUMENTS
        ]
        document_files = len(project_documents)
        relevant_files = max(1, len(files))
        if document_files >= 3 and document_files / relevant_files >= 0.5:
            score += 3
            evidence.append(f"documentation ratio: {document_files}/{relevant_files}")
        elif not project_documents and not any(
            marker in relative_files or marker in file_names or _existing_marker(root, marker)
            for marker in profile.get("strong_markers", [])
        ):
            # The foundation files created by HYN-Skill must not turn an ordinary
            # project into a docs project on the next idempotent scan.
            return 0, []

    unique_signals = len(evidence)
    minimum_signals = int(profile.get("minimum_signals", 1))
    if unique_signals < minimum_signals:
        return 0, []
    return score, evidence


def _detect_profiles(root: Path, profiles: dict[str, dict[str, Any]]) -> dict[str, Any]:
    files = list(_iter_files(root))
    scored: list[dict[str, Any]] = []
    for name, profile in profiles.items():
        if name == "generic":
            continue
        score, evidence = _score_profile(root, profile, files)
        if score:
            scored.append({"profile": name, "score": score, "evidence": evidence})
    scored.sort(key=lambda item: (-item["score"], item["profile"]))
    if not scored:
        resolved = "generic"
        warnings = ["没有足够的项目类型证据，使用 generic profile。"]
    elif len(scored) > 1 and scored[0]["score"] == scored[1]["score"]:
        resolved = "generic"
        warnings = [
            "多个 profile 得分相同，未强行猜测，使用 generic profile。"
            f"候选: {', '.join(item['profile'] for item in scored if item['score'] == scored[0]['score'])}。"
        ]
    else:
        resolved = scored[0]["profile"]
        warnings = []
    return {
        "resolved": resolved,
        "candidates": scored,
        "files_scanned": len(files),
        "warnings": warnings,
    }


def _git_summary(root: Path) -> dict[str, Any]:
    if not (root / ".git").exists():
        return {"kind": "not-git", "status": "not a Git working tree"}
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "status", "--short"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        return {"kind": "git-unavailable", "status": str(exc)}
    if result.returncode != 0:
        return {"kind": "git-error", "status": result.stderr.strip() or "git status failed"}
    lines = [line for line in result.stdout.splitlines() if line.strip()]
    return {
        "kind": "git",
        "status": "dirty" if lines else "clean",
        "changed_count": len(lines),
        "sample": lines[:10],
    }


def _detect_language(root: Path, configured: str) -> str:
    if configured != "auto":
        return configured
    samples: list[str] = []
    for name in ("README.md", "CONTEXT.md", "AGENTS.md"):
        path = root / name
        if path.is_file():
            try:
                samples.append(path.read_text(encoding="utf-8")[:8000])
            except UnicodeDecodeError:
                continue
    combined = "\n".join(samples)
    if re.search(r"[\u4e00-\u9fff]", combined):
        return "zh-CN"
    if samples:
        return "en"
    # Empty projects use HYN's Chinese default; an existing English project is
    # recognized from its current entry documents.
    return "zh-CN"


def _command_hints(root: Path, profile: str) -> list[str]:
    hints: list[str] = []
    package_json = root / "package.json"
    if package_json.is_file():
        try:
            data = json.loads(package_json.read_text(encoding="utf-8"))
            scripts = data.get("scripts", {}) if isinstance(data, dict) else {}
            if isinstance(scripts, dict) and scripts:
                names = ", ".join(f"`{name}`" for name in sorted(scripts))
                hints.append(f"`package.json` 声明的 scripts: {names}；请确认开发、构建和测试入口。")
            else:
                hints.append("检测到 `package.json`，但未发现 scripts；请补充已验证的开发和测试命令。")
        except (OSError, json.JSONDecodeError) as exc:
            hints.append(f"检测到 `package.json`，但读取 scripts 失败；请人工确认命令（{exc}）。")
    if profile == "python" or any((root / name).exists() for name in ("pyproject.toml", "requirements.txt", "setup.py")):
        hints.append("检测到 Python 项目入口；请确认解释器、依赖安装、运行和测试命令。")
    if profile == "cpp" or any((root / name).exists() for name in ("CMakeLists.txt", "meson.build", "Makefile")):
        hints.append("检测到 C/C++ 构建入口；请确认 configure/build/test 命令和工具链。")
    if profile == "docs" or any((root / name).exists() for name in ("mkdocs.yml", "book.toml", "SUMMARY.md")):
        hints.append("检测到文档发布入口；请确认预览、构建和发布命令。")
    if not hints:
        hints.append("未推断出可执行命令；请记录一个已验证的开发或检查入口。")
    return hints


def _format_bullets(items: list[str], empty: str) -> str:
    if not items:
        return f"- {empty}"
    return "\n".join(f"- {item}" for item in items)


def _links_for(kind: str, level: str, history: str) -> tuple[str, str]:
    if kind in {"root", "agents"}:
        context = "- [Current context](CONTEXT.md)"
        links = ["- [Documentation index](docs/README.md)"]
        if level in {"standard", "deep"}:
            links.extend(
                [
                    "- [Decision records](docs/decisions/README.md)",
                    "- [Verification index](docs/verification/README.md)",
                    "- [Learning index](learn/README.md)",
                ]
            )
        if level == "deep" and history != "none":
            links.append("- [Historical archive](docs/archive/README.md)")
        return context, "\n".join(links)

    context = "- [Current context](../CONTEXT.md)"
    links = ["- [Decision records](decisions/README.md)", "- [Verification index](verification/README.md)"]
    if level == "deep":
        links.extend(["- [Glossary](glossary.md)", "- [Learning map](../learn/map.md)"])
        if history != "none":
            links.append("- [Historical archive](archive/README.md)")
    if level in {"standard", "deep"}:
        links.append("- [Learning index](../learn/README.md)")
    return context, "\n".join(links)


def _template_context(
    root: Path,
    effective: dict[str, Any],
    resolved_profile: str,
    profile: dict[str, Any],
    detection: dict[str, Any],
    git: dict[str, Any],
    level: str,
    language: str,
    history: str,
) -> dict[str, str]:
    profile_label = str(profile.get("label", resolved_profile))
    evidence: list[str] = [
        f"Profile detection scanned {detection['files_scanned']} project file(s).",
        f"Git state: {git.get('status', 'unknown')}.",
    ]
    candidates = detection.get("candidates", [])
    if candidates:
        evidence.append(
            "Candidates: "
            + ", ".join(f"{item['profile']} ({item['score']})" for item in candidates[:4])
            + "."
        )
        evidence.extend(f"{item}" for item in candidates[0].get("evidence", [])[:6])
    else:
        evidence.append("No specialized profile marker was strong enough to select.")

    focus = [str(item) for item in profile.get("focus", [])]
    commands = _command_hints(root, resolved_profile)
    root_context, root_docs = _links_for("root", level, history)
    docs_context, docs_links = _links_for("docs", level, history)
    return {
        "PROJECT_NAME": root.name,
        "PROFILE": resolved_profile,
        "PROFILE_LABEL": profile_label,
        "LEVEL": level,
        "LANGUAGE": language,
        "DATE": _datetime.date.today().isoformat(),
        "EVIDENCE": _format_bullets(evidence, "暂无扫描证据。"),
        "COMMANDS": _format_bullets(commands, "未推断出可执行命令。"),
        "FOCUS": _format_bullets(focus, "先明确项目目标和事实拥有者。"),
        "CONTEXT_LINKS": root_context,
        "DOC_LINKS": root_docs,
        "DOC_CONTEXT_LINKS": docs_context,
        "DOC_PAGE_LINKS": docs_links,
        "HISTORY_POLICY": history,
        "PROFILE_NOTES": _format_bullets(focus, "暂无 profile 专属提醒。"),
        "CONFIG_PROFILE": str(effective.get("profile", "auto")),
    }


def _render_template(template_name: str, context: dict[str, str]) -> str:
    language = context.get("LANGUAGE", "zh-CN")
    localized = TEMPLATE_ROOT / language / template_name
    path = localized if language == "en" and localized.is_file() else TEMPLATE_ROOT / template_name
    if not path.is_file():
        raise HynError(f"缺少模板文件: {path}")
    content = path.read_text(encoding="utf-8")
    for key, value in context.items():
        content = content.replace("{{" + key + "}}", value)
    unresolved = sorted(set(re.findall(r"\{\{[^{}]+\}\}", content)))
    if unresolved:
        raise HynError(f"模板 {path} 存在未解析变量: {', '.join(unresolved)}")
    return content.rstrip() + "\n"


def _files_for_level(level: str, history: str) -> list[tuple[str, str, str]]:
    files: list[tuple[str, str, str]] = [
        ("README.md", "README.md", "root"),
        ("CONTEXT.md", "CONTEXT.md", "context"),
        ("docs/README.md", "docs-index.md", "docs"),
    ]
    if level in {"standard", "deep"}:
        files.extend(
            [
                ("AGENTS.md", "AGENTS.md", "agents"),
                ("docs/decisions/README.md", "decisions-index.md", "docs"),
                ("docs/verification/README.md", "verification-index.md", "docs"),
                ("learn/README.md", "learn-index.md", "learn"),
            ]
        )
    if level == "deep":
        files.extend(
            [
                ("docs/glossary.md", "glossary-index.md", "docs"),
                ("learn/map.md", "learn-map.md", "learn"),
            ]
        )
        if history != "none":
            files.append(("docs/archive/README.md", "archive-index.md", "docs"))
    return files


def _render_for_kind(template_name: str, kind: str, context: dict[str, str]) -> str:
    adjusted = dict(context)
    if kind == "docs":
        adjusted["CONTEXT_LINKS"] = context["DOC_CONTEXT_LINKS"]
        adjusted["DOC_LINKS"] = context["DOC_PAGE_LINKS"]
    elif kind in {"root", "agents"}:
        adjusted["CONTEXT_LINKS"] = context["CONTEXT_LINKS"]
        adjusted["DOC_LINKS"] = context["DOC_LINKS"]
    return _render_template(template_name, adjusted)


def _project_configuration(root: Path) -> Path:
    return root / PROJECT_CONFIG_NAME


def _resolve(root: Path, overrides: dict[str, Any]) -> dict[str, Any]:
    defaults = _validate_config(_load_defaults(), DEFAULT_CONFIG_PATH)
    profiles = _load_profiles()
    detection = _detect_profiles(root, profiles)
    global_path = _global_config_path()
    project_path = _project_configuration(root)
    global_config, global_sources = _read_optional_config(global_path)
    project_config, project_sources = _read_optional_config(project_path)

    requested_profile = str(overrides.get("profile") or project_config.get("profile") or global_config.get("profile") or defaults.get("profile", "auto"))
    if requested_profile == "auto":
        resolved_profile = detection["resolved"]
    else:
        resolved_profile = requested_profile
    if resolved_profile not in profiles:
        raise HynError(f"Profile {resolved_profile!r} 没有定义。")

    effective = dict(defaults)
    profile_default_level = profiles[resolved_profile].get("suggested_level")
    if profile_default_level in LEVELS:
        effective["level"] = profile_default_level
    effective.update(global_config)
    effective.update(project_config)
    effective.update({key: value for key, value in overrides.items() if value is not None})
    effective["profile"] = requested_profile
    effective = _validate_config(effective, project_path if project_path.exists() else DEFAULT_CONFIG_PATH)

    if effective["profile"] == "auto":
        resolved_profile = detection["resolved"]
    else:
        resolved_profile = effective["profile"]
    if resolved_profile not in profiles:
        raise HynError(f"Profile {resolved_profile!r} 没有定义。")
    if effective["level"] not in LEVELS:
        raise HynError(f"初始化级别无效: {effective['level']}")

    source_paths = [str(DEFAULT_CONFIG_PATH), *global_sources, *project_sources]
    if overrides:
        source_paths.append("<explicit CLI/user overrides>")
    return {
        "effective": effective,
        "resolved_profile": resolved_profile,
        "profiles": profiles,
        "detection": detection,
        "source_paths": source_paths,
        "global_config": str(global_path),
        "project_config": str(project_path),
    }


def _build_report(root: Path, overrides: dict[str, Any]) -> dict[str, Any]:
    if not root.exists():
        raise HynError(f"项目目录不存在: {root}")
    if not root.is_dir():
        raise HynError(f"项目路径不是目录: {root}")

    resolved = _resolve(root, overrides)
    effective = resolved["effective"]
    profile_name = resolved["resolved_profile"]
    profile = resolved["profiles"].get(profile_name, PROFILES_FALLBACK["generic"])
    level = effective["level"]
    history = effective["history"]
    language = _detect_language(root, effective["language"])
    git = _git_summary(root)
    context = _template_context(
        root,
        effective,
        profile_name,
        profile,
        resolved["detection"],
        git,
        level,
        language,
        history,
    )

    files_to_create: list[dict[str, str]] = []
    files_to_skip: list[dict[str, str]] = []
    conflicts: list[dict[str, str]] = []
    for relative, template, kind in _files_for_level(level, history):
        destination = root / relative
        if os.path.lexists(str(destination)):
            if destination.is_file():
                files_to_skip.append({"path": relative, "reason": "existing file preserved"})
            else:
                conflicts.append({"path": relative, "reason": "existing path is not a regular file"})
        else:
            _render_for_kind(template, kind, context)
            files_to_create.append({"path": relative, "template": template})

    warnings = list(resolved["detection"].get("warnings", []))
    if git.get("status") == "dirty":
        warnings.append("项目存在未提交改动；初始化只会创建缺失文件，不会触碰已有文件。")
    if conflicts:
        warnings.append("部分目标路径已存在但不是普通文件，初始化不会覆盖。")
    return {
        "project": str(root),
        "project_name": root.name,
        "profile": {
            "requested": effective["profile"],
            "resolved": profile_name,
            "label": profile.get("label", profile_name),
            "candidates": resolved["detection"].get("candidates", []),
            "files_scanned": resolved["detection"].get("files_scanned", 0),
        },
        "configuration": {
            "sources": resolved["source_paths"],
            "global_path": resolved["global_config"],
            "project_path": resolved["project_config"],
            "effective": effective,
            "resolved_language": language,
        },
        "git": git,
        "files_to_create": files_to_create,
        "files_to_skip": files_to_skip,
        "conflicts": conflicts,
        "warnings": warnings,
        "next_actions": [
            "补充 README.md 的项目目标和最小运行入口。",
            "在 CONTEXT.md 中确认事实拥有者、边界和未决问题。",
            "用已验证的命令替换模板中的待确认提示。",
            "在行为或架构发生重要变化时更新 docs/ 和 verification 记录。",
        ],
        "_context": context,
        "_resolved": resolved,
    }


def _apply_report(report: dict[str, Any]) -> list[str]:
    root = Path(report["project"])
    created: list[str] = []
    context = report["_context"]
    for item in report["files_to_create"]:
        relative = item["path"]
        destination = root / relative
        content = _render_for_kind(item["template"], _kind_for_relative(relative), context)
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            with destination.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(content)
            created.append(relative)
        except FileExistsError:
            # A concurrent creator wins; preserve it just like any pre-existing file.
            continue
    return created


def _kind_for_relative(relative: str) -> str:
    if relative == "README.md":
        return "root"
    if relative == "AGENTS.md":
        return "agents"
    if relative == "CONTEXT.md":
        return "context"
    if relative.startswith("docs/"):
        return "docs"
    return "learn"


def _text_report(report: dict[str, Any], applied: list[str] | None = None) -> str:
    profile = report["profile"]
    configuration = report["configuration"]
    lines = [
        f"Project: {report['project_name']}",
        f"Profile: {profile['resolved']} ({profile['label']})",
        f"Requested profile: {profile['requested']}",
        f"Level: {configuration['effective']['level']}",
        f"Language: {configuration['resolved_language']}",
        f"History: {configuration['effective']['history']}",
        f"Scanned files: {profile['files_scanned']}",
        f"Git: {report['git'].get('status', 'unknown')}",
        "",
        "Configuration sources:",
    ]
    lines.extend(f"  - {source}" for source in configuration["sources"])
    lines.extend(["", "Files to create:"])
    if report["files_to_create"]:
        lines.extend(f"  - {item['path']}  ({item['template']})" for item in report["files_to_create"])
    else:
        lines.append("  - none")
    lines.append("Existing files skipped:")
    if report["files_to_skip"]:
        lines.extend(f"  - {item['path']}  ({item['reason']})" for item in report["files_to_skip"])
    else:
        lines.append("  - none")
    if report["conflicts"]:
        lines.append("Conflicts:")
        lines.extend(f"  - {item['path']}  ({item['reason']})" for item in report["conflicts"])
    lines.append("Warnings:")
    if report["warnings"]:
        lines.extend(f"  - {warning}" for warning in report["warnings"])
    else:
        lines.append("  - none")
    if applied is not None:
        lines.append("Created in apply phase:")
        if applied:
            lines.extend(f"  - {path}" for path in applied)
        else:
            lines.append("  - none")
    lines.append("Recommended next actions:")
    lines.extend(f"  - {action}" for action in report["next_actions"])
    return "\n".join(lines)


def _emit(report: dict[str, Any], output_format: str, applied: list[str] | None = None) -> None:
    clean = {key: value for key, value in report.items() if not key.startswith("_")}
    if applied is not None:
        clean["created"] = applied
    if output_format == "json":
        print(json.dumps(clean, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(_text_report(report, applied))


def _overrides(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "profile": args.profile,
        "level": args.level,
        "language": args.language,
        "history": args.history,
    }


def _add_project_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--project", required=True, help="项目根目录")
    parser.add_argument("--profile", choices=("auto", *PROFILE_NAMES), help="显式覆盖项目 profile")
    parser.add_argument("--level", choices=LEVELS, help="显式覆盖初始化级别")
    parser.add_argument("--language", choices=LANGUAGES, help="显式覆盖文档语言偏好")
    parser.add_argument("--history", choices=HISTORY_MODES, help="显式覆盖历史归档策略")
    parser.add_argument("--format", choices=("text", "json"), default="text", help="输出格式")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Inspect and initialize a HYN project foundation.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    inspect = subparsers.add_parser("inspect", help="只读扫描项目并输出初始化计划")
    _add_project_options(inspect)

    init = subparsers.add_parser("init", help="扫描并计划初始化；默认只读")
    _add_project_options(init)
    init.add_argument("--apply", action="store_true", help="创建缺失文件；不覆盖已有文件")

    validate = subparsers.add_parser("validate-config", help="验证一个 TOML 配置文件")
    validate.add_argument("--config", required=True, help="TOML 配置路径")
    validate.add_argument("--format", choices=("text", "json"), default="text", help="输出格式")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "validate-config":
            path = Path(args.config).expanduser().resolve()
            data, _ = _read_optional_config(path)
            if not path.exists():
                raise HynError(f"配置文件不存在: {path}")
            result = {"valid": True, "config": data, "path": str(path)}
            if args.format == "json":
                print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
            else:
                print(f"Valid configuration: {path}")
                for key, value in data.items():
                    print(f"  {key} = {value!r}")
            return 0

        root = Path(args.project).expanduser().resolve()
        report = _build_report(root, _overrides(args))
        if args.command == "init" and args.apply:
            created = _apply_report(report)
            # Refresh the report so a second inspection shows the actual post-apply state.
            final_report = _build_report(root, _overrides(args))
            _emit(final_report, args.format, created)
        else:
            _emit(report, args.format)
        return 0
    except HynError as exc:
        print(f"HYN-Skill error: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"HYN-Skill filesystem error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
