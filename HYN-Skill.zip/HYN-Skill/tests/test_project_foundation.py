#!/usr/bin/env python3
"""Behavior tests for HYN-Skill's deterministic project helper."""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))
import project_foundation as foundation  # noqa: E402


class FoundationTest(unittest.TestCase):
    def make_project(self) -> tempfile.TemporaryDirectory[str]:
        return tempfile.TemporaryDirectory(prefix="hyn-foundation-test-")

    def report(self, root: Path, **overrides: str) -> dict:
        return foundation._build_report(root, overrides)

    def test_empty_project_plan_is_read_only(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            report = self.report(root)
            self.assertEqual(report["profile"]["resolved"], "generic")
            self.assertEqual(len(report["files_to_create"]), 7)
            self.assertEqual(list(root.iterdir()), [])

    def test_apply_is_idempotent_and_profile_stays_stable(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            first = self.report(root)
            created = foundation._apply_report(first)
            self.assertEqual(len(created), 7)

            second = self.report(root)
            self.assertEqual(second["profile"]["resolved"], "generic")
            self.assertEqual(second["files_to_create"], [])
            self.assertEqual(len(second["files_to_skip"]), 7)
            self.assertEqual(foundation._apply_report(second), [])

    def test_existing_files_are_preserved(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            readme = root / "README.md"
            readme.write_text("user-owned content\n", encoding="utf-8")
            before = readme.read_bytes()

            report = self.report(root)
            self.assertIn({"path": "README.md", "reason": "existing file preserved"}, report["files_to_skip"])
            foundation._apply_report(report)
            self.assertEqual(readme.read_bytes(), before)

    def test_python_profile(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            (root / "pyproject.toml").write_text("[project]\nname='demo'\n", encoding="utf-8")
            (root / "main.py").write_text("print('ok')\n", encoding="utf-8")
            self.assertEqual(self.report(root)["profile"]["resolved"], "python")

    def test_cpp_profile(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            (root / "CMakeLists.txt").write_text("cmake_minimum_required(VERSION 3.20)\n", encoding="utf-8")
            (root / "main.cpp").write_text("int main() { return 0; }\n", encoding="utf-8")
            self.assertEqual(self.report(root)["profile"]["resolved"], "cpp")

    def test_typescript_profile(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            (root / "package.json").write_text(
                json.dumps({"scripts": {"test": "vitest"}}), encoding="utf-8"
            )
            (root / "tsconfig.json").write_text("{}\n", encoding="utf-8")
            (root / "main.ts").write_text("export const ok = true;\n", encoding="utf-8")
            self.assertEqual(self.report(root)["profile"]["resolved"], "typescript-web")

    def test_ai_agent_needs_multiple_signals(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            (root / "skills").mkdir()
            (root / "skills" / "README.md").write_text("one signal\n", encoding="utf-8")
            self.assertEqual(self.report(root)["profile"]["resolved"], "generic")

            (root / "evals").mkdir()
            (root / "evals" / "basic.yaml").write_text("cases: []\n", encoding="utf-8")
            self.assertEqual(self.report(root)["profile"]["resolved"], "ai-agent")

    def test_docs_profile_requires_project_documents(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            (root / "mkdocs.yml").write_text("site_name: demo\n", encoding="utf-8")
            self.assertEqual(self.report(root)["profile"]["resolved"], "docs")

    def test_tied_detection_falls_back_to_generic(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            (root / "pyproject.toml").write_text("[project]\nname='demo'\n", encoding="utf-8")
            (root / "CMakeLists.txt").write_text("cmake_minimum_required(VERSION 3.20)\n", encoding="utf-8")
            report = self.report(root)
            self.assertEqual(report["profile"]["resolved"], "generic")
            self.assertTrue(any("相同" in warning for warning in report["warnings"]))

    def test_configuration_precedence(self) -> None:
        with self.make_project() as path, tempfile.TemporaryDirectory(prefix="hyn-global-") as config_home:
            root = Path(path)
            global_dir = Path(config_home) / "hyn-skill"
            global_dir.mkdir()
            (global_dir / "preferences.toml").write_text(
                'schema_version = 1\nlevel = "lean"\nprofile = "python"\n', encoding="utf-8"
            )
            (root / ".hyn-skill.toml").write_text(
                'schema_version = 1\nlevel = "deep"\nprofile = "cpp"\n', encoding="utf-8"
            )
            with mock.patch.dict(os.environ, {"XDG_CONFIG_HOME": config_home}, clear=False):
                report = self.report(root, level="standard")
            self.assertEqual(report["configuration"]["effective"]["level"], "standard")
            self.assertEqual(report["configuration"]["effective"]["profile"], "cpp")
            self.assertEqual(report["profile"]["resolved"], "cpp")

    def test_invalid_configuration_writes_nothing(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            (root / ".hyn-skill.toml").write_text("unexpected = true\n", encoding="utf-8")
            with self.assertRaises(foundation.HynError):
                self.report(root)
            self.assertEqual(list(root.iterdir()), [root / ".hyn-skill.toml"])

    def test_deep_without_history_skips_archive(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            report = self.report(root, level="deep", history="none")
            foundation._apply_report(report)
            self.assertTrue((root / "docs/glossary.md").is_file())
            self.assertTrue((root / "learn/map.md").is_file())
            self.assertFalse((root / "docs/archive/README.md").exists())

    def test_english_configuration_uses_english_templates(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            report = self.report(root, language="en", level="lean")
            foundation._apply_report(report)
            readme = (root / "README.md").read_text(encoding="utf-8")
            self.assertIn("Project foundation", readme)
            self.assertNotIn("项目基础", readme)

    def test_generated_documents_do_not_contain_project_absolute_path(self) -> None:
        with self.make_project() as path:
            root = Path(path)
            report = self.report(root)
            foundation._apply_report(report)
            for file in root.rglob("*"):
                if file.is_file():
                    self.assertNotIn(str(root), file.read_text(encoding="utf-8"))

    def test_json_report_is_serializable(self) -> None:
        with self.make_project() as path:
            report = self.report(Path(path))
            public = {key: value for key, value in report.items() if not key.startswith("_")}
            json.dumps(public, ensure_ascii=False)


if __name__ == "__main__":
    unittest.main()
