# Documentation index

This is the formal documentation entry point for **{{PROJECT_NAME}}**.

## Current context

{{CONTEXT_LINKS}}

## Stable documentation

{{DOC_LINKS}}

## Documentation rules

- Keep current behavior in current documents.
- Record design rationale in a decision record when the reason matters.
- Record verification conditions and evidence separately from proposals.
- Archive only material historical states.
- Avoid creating a second index for the same topic.
