# Historical archive

Use this directory only for material historical states that explain how the project reached its current behavior.

An archive record should identify:

- the date or release boundary;
- the state being recorded;
- the evidence available at that time;
- the reason the record remains useful;
- links to the current replacement or follow-up decision.

Do not use this directory as a daily activity log.
