# {{PROJECT_NAME}}

## Project foundation

- Detected profile: `{{PROFILE}}` ({{PROFILE_LABEL}})
- Initialization level: `{{LEVEL}}`
- Documentation language: `{{LANGUAGE}}`
- Foundation date: `{{DATE}}`

## Purpose

<!-- Replace this section with the actual purpose and scope. Do not describe an assumption as a current fact. -->

## Quick start

<!-- Record the smallest verified setup and run commands here. -->

{{COMMANDS}}

## Current context

{{CONTEXT_LINKS}}

## Documentation

{{DOC_LINKS}}

## Verification status

<!-- Link or summarize the evidence supporting the current project status. -->

## Open questions

- Which important project fact or boundary still needs confirmation?
