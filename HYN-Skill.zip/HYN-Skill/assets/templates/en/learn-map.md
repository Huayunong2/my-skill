# Learning map

Use this map to guide future maintainers through the project's non-obvious knowledge.

Suggested order:

1. Read `README.md` for purpose and quick start.
2. Read `CONTEXT.md` for current facts, vocabulary, and boundaries.
3. Read `docs/README.md` for stable decisions and verification evidence.
4. Read the relevant notes under `learn/` only when the current task needs them.

Keep this map as an index. Put detailed knowledge in focused notes and link back to the evidence or source that supports it.
