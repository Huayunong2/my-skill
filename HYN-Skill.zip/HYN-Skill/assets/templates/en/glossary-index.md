# Project glossary

Use this file for terms whose meaning is specific to **{{PROJECT_NAME}}**.

For each important term, record:

- preferred name;
- meaning in this project;
- nearby concepts that must not be confused with it;
- source of the definition;
- owner when the term represents a durable fact.

Avoid adding synonyms that create multiple names for one fact.
