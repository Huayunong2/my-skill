# Learning index

`learn/` stores useful knowledge that crosses tasks or is not yet stable enough to become project authority.

Keep each note small and link it to the source code, decision, test, measurement, or external reference that supports it.

When a lesson recurs across projects, record a promotion candidate instead of silently changing HYN-Skill. Promote it only after checking applicability, cost, and counterexamples.

Project truth remains in `CONTEXT.md` and `docs/`; this directory is not a replacement for those sources.
