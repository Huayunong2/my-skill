# Verification index

Record what was checked, under which conditions, and what remains unknown.

Use evidence labels consistently:

- current code fact;
- static check;
- automated test;
- measurement;
- simulated or replay run;
- real-environment observation;
- inference;
- proposal;
- pending verification.

Do not promote a host-only or simulated result into a real-environment claim. Link detailed records from this index.
