# Decision records

Use this directory for decisions whose rationale should remain discoverable after implementation changes.

Each decision should state:

- context and constraints;
- considered alternatives;
- selected decision and why;
- consequences and verification status;
- conditions that would justify revisiting it.

Do not create a decision record for a trivial implementation detail. Link decisions from `docs/README.md`.
