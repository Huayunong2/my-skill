# {{PROJECT_NAME}} context

## Current identity

- Profile: `{{PROFILE}}` ({{PROFILE_LABEL}})
- Foundation level: `{{LEVEL}}`
- Last foundation scan: {{DATE}}

## Purpose and scope

<!-- State what this project does, for whom, and what it deliberately does not do. -->

## Current facts

<!-- Record facts supported by the repository, tests, measurements, or explicit project decisions. -->

- Repository entry point: `README.md`
- Project rules: `AGENTS.md` when present
- Formal documentation: `docs/README.md`

## Domain vocabulary

<!-- Define terms that have a project-specific meaning. Avoid introducing synonyms for the same fact. -->

## Ownership and boundaries

{{FOCUS}}

- Main input boundary: to be confirmed.
- Main output or side-effect boundary: to be confirmed.
- Asynchronous work owner: to be confirmed if applicable.
- Persistence or publication boundary: to be confirmed if applicable.

## Observable evidence

{{EVIDENCE}}

## Development and verification entry points

{{COMMANDS}}

## Open questions

- Which important fact currently has no authoritative owner?
- Which behavior is inferred rather than verified?
- What should be recorded in a decision document before the next material change?
