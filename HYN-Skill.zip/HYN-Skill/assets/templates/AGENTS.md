# Agent instructions for {{PROJECT_NAME}}

This file contains rules for this project. Personal HYN preferences remain in HYN-Skill and are not copied here.

## Project scope

- Profile: `{{PROFILE}}` ({{PROFILE_LABEL}})
- Read `CONTEXT.md` before changing architecture or durable state.
- Use `docs/README.md` to find current project documentation.

## Before changes

- Inspect existing implementations and tests before adding a parallel path.
- Preserve unrelated local changes.
- Identify the owner of each fact or resource touched by the change.
- Keep assumptions, proposals, and verified facts separate.

## Development commands

{{COMMANDS}}

Confirm commands against the repository before treating them as authoritative.

## Architecture and ownership

- Keep input, side effects, asynchronous work, persistence, and public interfaces at explicit boundaries.
- Do not maintain a second mutable source of truth for the same project fact.
- Record lifecycle, cancellation, timeout, and partial-completion behavior when they matter.

## Verification

- Run checks proportional to the changed behavior.
- Distinguish static checks, automated tests, measurements, simulated runs, and real-environment validation.
- Do not claim coverage or hardware behavior that was not actually verified.

## Safety

- Do not perform destructive, irreversible, or externally visible operations without explicit authorization.
- Avoid deleting or overwriting project data during routine maintenance.
- Preserve useful failure evidence and uncertain side effects.

## Source documents

{{CONTEXT_LINKS}}

{{DOC_LINKS}}
